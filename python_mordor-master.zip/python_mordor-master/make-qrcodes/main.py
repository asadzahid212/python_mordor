import qrcode
import csv
from getMerchants import getMerchants

import requests
import os
import json
from bs4 import BeautifulSoup

import shutil

def main(merchant_ari):
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/' % (merchant_ari)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	soup = BeautifulSoup(res.text, 'html.parser')
	name_div = soup.find(class_="merchant-nav-info")
	merchant_name = name_div.find('h3').text

	path = './'+merchant_name
	if not os.path.exists(path):
		os.makedirs(path)
	sms_codes, store_aris, display_names = getSMScodes(merchant_ari)
	for i in range(len(sms_codes)):
		sms_code = sms_codes[i].decode_contents(formatter='html')
		store_ari = store_aris[i].decode_contents(formatter='html')
		display_name = display_names[i].decode_contents(formatter='html')
		# print('code: ' + sms_keyword)
		# if sms_code.upper() == sms_keyword.upper():
			# validation = True
		create_qr_code(merchant_ari=merchant_ari,sms_code=sms_code,store_ari=store_ari,display_name=display_name,path=path)

	shutil.make_archive(merchant_name, 'zip', path)

def getSMScodes(merchant_ari):
	
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/sms_keywords/' % (merchant_ari)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	# print(data)
	# input(url)
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	if res.status_code != 200:
		input('ERROR')
	# saveResponse(res.text, "checkSMS")
	soup = BeautifulSoup(res.text, 'html.parser')
	sms_codes = soup.find_all(class_="sms_keyword")
	store_aris = soup.find_all(class_="store_ari")
	display_names = soup.find_all(class_="display_name")
	# print('sms codes: ' + str(sms_codes))
	# sms_keyword = SMS['sms_keyword']
	# validation = False
	return sms_codes, store_aris, display_names


def create_qr_code(merchant_ari,sms_code,store_ari,display_name,path):
	landing_page_keyword = get_landing_page_keyword(merchant_ari)
	url = "https://www.affirm.com/shop/" + landing_page_keyword + "?store_ari=" + store_ari

	img = qrcode.make(url)

	img.save(path + '/' + display_name + ".png")
	print(url)


def get_landing_page_keyword(merchant_ari):
	
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/omnichannel_conf/' % (merchant_ari)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	# print(data)
	if res.status_code != 200:
		print('ERROR')
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()

	soup = BeautifulSoup(res.text, 'html.parser')

	landing_page_keyword = str(soup.find(id="instore_landing_page_url")['value'])
	return landing_page_keyword

merchants = getMerchants('csvs/make-qrcodes.csv')
for merchant_ari in merchants:
# merchant_ari = '2CSVU1B6E96UBCDG'
	main(merchant_ari)