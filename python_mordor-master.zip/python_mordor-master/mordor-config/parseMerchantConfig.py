#in: HTML of merchant's mordor, page_type
#out: JSON of structure:
"""
{
	"merchant-conf": {
		key1: value1,
		...
	},
	"info": {
		keyA: valueA,
		...
	},
	...
}
"""
from bs4 import BeautifulSoup

def parseMerchantConfig(html_doc, page_type):
	soup = BeautifulSoup(html_doc, 'html.parser')
	conf_html = soup.find(id=page_type)
	print(html_doc)
	inputs = conf_html.find_all('input')
	# print(inputs)
	selects = conf_html.find_all('select') #if it has 'selected' attribute, it's ..selected
	textareas = conf_html.find_all('textarea')

	conf_json = {page_type: {}}
	current_json = {}

	for textarea in textareas:
		current_json[textarea['id']] = textarea.decode_contents(formatter='html')

	for putin in inputs:
		if putin['type'] == 'checkbox':
			try:
				putin['checked']
				current_json[putin['id']] = 'y' 
			except:
				current_json[putin['id']] = ''
		elif putin['type'] in ('text', 'datetime'):
			current_json[putin['id']] = putin['value']
		elif putin['type'] == 'hidden':
			input_field = putin.parent.find('input', class_="hidden-fields")
			try:
				input_field['checked']
				current_json[putin['id']] = 'true'
			except:
				current_json[putin['id']] = 'false'
		elif putin['type'] == 'submit':
			pass
		else:
			raise NameError('New type: ' + putin['type'])

	for select in selects:

		try:
			print('SELECT IS')
			print(select)
			value = None
			text =[]
			for i in select:
				print('PRINTING I')
				print(i)
				if 'selected=""' in str(i):
					print(i)
					text.append(i.decode_contents(formatter='html'))
				if len(text) > 1:
					print(text)
					print(selects)
					input('how are there more than one selected?')
				if select['id'] in ['card_product_identifier', 'als_card_product_identifier']:
					text=[i.value]
			value = text[0]
			# value = select.find('option', {"selected":""})['value']
			
			current_json[select['id']] = value
			print(' value = ' + str(value))
			print('current_json')
			# input('WAIT WHATs')
		except:
			raise NameError('No value on: ' + str(select))

	conf_json[page_type] = current_json
	# print(conf_json)
	return conf_json

# with open("myfile.html") as file:
# 	data = file.read()
# 	parseMerchantConfig(data, 'merchant-conf')
