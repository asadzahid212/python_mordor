from forEachMerchant import forEachMerchant
from getUpdates import getUpdates


def mainConfig(settings):		
	print(settings)
	#input('does this config look right?')
	forEachMerchant(settings)


mainConfig(getUpdates('csvs/mordor-config.csv'))