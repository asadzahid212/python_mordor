#in: List of merchant merchant_aris
#out: Confirmation that it worked
from getMerchantConfig import getMerchantConfig
from updateConfig import updateConfig
from updateMordor import updateMordor
# from checkNewConfig import checkNewConfig
from getUpdates import getUpdates
from cleanConfig import cleanConfig
# from checkCategoryCode import checkCategoryCode

def forEachMerchant(updates):
	updates = updates #getUpdates(file_name)
	print(updates)
	for i in updates:
		update = updates[i]
		print("update")
		print(update)
		merchant_ari = update['merchant_ari']
		print('Getting config for: ' + merchant_ari)
		merchant_config = getMerchantConfig(merchant_ari, 'merchant-conf')
		print('Updating config for: ' + merchant_ari)
		updated_config = updateConfig(merchant_config, update, 'merchant-conf')
		print('Cleaning config for: ' + merchant_ari)
		clean_config = cleanConfig(updated_config, 'merchant-conf')
		print('Updating Mordor for: ' + merchant_ari)
		updated_mordor = updateMordor(merchant_ari, clean_config, 'merchant-conf')

		# cat_code_check = checkCategoryCode(updated_mordor, merchant_ari)

		# print("has category code?: "+ str(cat_code_check))
		
		# print('Compmerchant_aring configs: ' + merchant_ari)
		# checkNewConfig(merchant_ari, updated_config)
