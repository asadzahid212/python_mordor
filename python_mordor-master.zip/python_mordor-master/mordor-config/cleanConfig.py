import json

def cleanConfig(config, page_type):
	print(config)
	clean_config = dict(json.loads(json.dumps((config))))
	for key in config[page_type]:
		#remove any empties to make sure it doesn't reset form
		# if config[page_type][key] == '' and key not in ('prequal_financing_program', 'prequal_financing_program_uuid'):
			# clean_config[page_type].pop(key)
		#set hidden fields to true if original field is true
		try:
			config[page_type][key + '_hidden']
			if key == "prequal_enabled":
				print('JSDHFNJKS')
				print(key + '_hidden' + ': ' + config[page_type][key + '_hidden'])
				print(key + ': ' + config[page_type][key])
			if config[page_type][key] == 'y':
				clean_config[page_type][key + '_hidden'] = 'true'
			else:
				clean_config[page_type][key + '_hidden'] = 'false'
			if key == "prequal_enabled":
				print('JSDHFNJKS')
				print(key + '_hidden' + ': ' + config[page_type][key + '_hidden'])
				print(key + ': ' + config[page_type][key])
		except:
			pass
	print(clean_config)
	return clean_config