#in: merchant_ari, JSON of updated config
#out: confirmation that it's the same or identification of what's different