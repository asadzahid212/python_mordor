#in: merchant_ari, page_type
#out: JSON of structure:
"""
{
	"config": {
		key1: value1,
		...
	},
	"info": {
		keyA: valueA,
		...
	},
	...
}
"""
import requests
import json
import os
from parseMerchantConfig import parseMerchantConfig

def getMerchantConfig(merchant_ari, page_type):
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/' % (merchant_ari)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'cookie': 'admin_session=' + session_id,
	        'Accept': '*/*',
	        'Accept-Encoding': 'gzip, deflate, br',
	        'Connection': 'keep-alive',
	        # 'Cookie': 'admin_session=eyJsb2dpbl9zZXNzaW9uX2FyaSI6IlUzSFBHRENDQlhWWjlISVoifQ.EincUA.ewNGqVzK7Pwe3r_lCUWaASgPoMU'
	      }
	print(headers)
	res = requests.request(url=url, method=method, headers=headers)
	config = parseMerchantConfig(res.content, page_type)
	return config