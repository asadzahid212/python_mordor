import sys
sys.path.insert(1, '../shared')
from writeResultsToFirstColumnOfCSV import writeResultsToFirstColumnOfCSV

from bs4 import BeautifulSoup

def checkCategoryCode(updated_mordor, merchant_ari):
	soup = BeautifulSoup(updated_mordor, 'html.parser')
	category_code = soup.find(id="category")['value']

	writeResultsToFirstColumnOfCSV(file_name='csvs/all_settings.csv', value=category_code, match_value=merchant_ari, match_column='merchant_ari', target_col_header='has_category')

	if category_code != "":
		return True
	else:
		return False