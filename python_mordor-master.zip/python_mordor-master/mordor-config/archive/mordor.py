import requests
import os
import json

merchant_ari = '7KEU0TABF8VYEAKM'

url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/conf/' % (merchant_ari)
method = 'POST'
session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': 'admin_session=' + session_id,
      }
data = {"shipping_not_required":""}
res = requests.request(url=url, method=method, headers=headers, data=data)

print(res)
print(res.iter_lines())
print(res.status_code)
print(res.url)

file_object = open("myfile.txt", "w+")
file_object.write(res.text)
file_object.close()