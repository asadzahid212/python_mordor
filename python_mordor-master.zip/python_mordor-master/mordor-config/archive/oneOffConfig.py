from forEachMerchant import forEachMerchant
from getUpdates import getUpdates


def oneOffConfig(file_name):		
	settings = getUpdates(file_name)
	print(settings)
	#input('does this config look right?')
	forEachMerchant(settings)

oneOffConfig("mordorUpdates.csv")