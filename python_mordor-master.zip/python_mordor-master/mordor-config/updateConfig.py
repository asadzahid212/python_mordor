#in: config JSON, attributes to update
#out: updated config JSON

import csv
def updateConfig(old_config, update, page_type):
	new_config = dict(old_config[page_type])
	for key in update:
		if key not in old_config[page_type]:
			print('New key in config: ' + key)
			if key in ('merchant_ari', 'status'):
				continue
			else:
				raise NameError('Unknown key: ' + key)
		try:
			new_config[key] = update[key]
		except:
			print('Printing old config to help')
			print(old_config)
			raise NameError('Invalid key: ' + key)
	new_config = {page_type: new_config}
	return new_config

# update = {'ari': 'QOPXVCJU5GOKUOE9', 'auth_expiration_dt': '3', 'platform': 'VCN App', 'product_type': 'In-store', 'shipping_not_required': 'y', 'affirm_txn_fee_pct': '0.0199', 'vcn_enabled': 'y', 'vcn_offline': 'y', 'prequal_min_bound': '5000', 'prequal_max_bound': '700000', 'prequal_enabled': 'y'}
# old_config = {'merchant-conf': {'exposure_limit': '1000000.00', 'dispute_fee_amount': '15.00', 'capture_exceed_auth_limit_pct': '0.100000', 'txn_credit_limit': '20000.00', 'auth_expiration_dt': '5.0', 'default_currency': 'USD', 'min_loan_amount': '0.00', 'max_loan_amount': '', 'oms_escalation_contact': '', 'merchant_logo_url': '', 'fmtc_id': '', 'shipping_not_required': 'y', 'auto_auth_charge': '', 'inactive': '', 'use_invoicing': '', 'virtual_terminal_enabled': '', 'cybersource_enabled': '', 'settlement_details_include_financing_program': '', 'settlement_details_include_entity_name': '', 'settlement_details_include_user_info': '', 'settlement_details_include_merchant_transaction_id': '', 'test_merchant': '', 'iframe_enabled': '', 'settlement_details_include_dispute_reason': '', 'manual_financing_program_override': '', 'adjust_apr_on_capture': '', 'loan_abandonment_emails_enabled': '', 'user_decline_url_enabled': '', 'shopify_exchange_enabled': '', 'lto_enabled': '', 'white_labeling_enabled': '', 'hide_declined_ala': '', 'hide_merchant_info_on_signin': '', 'uses_bluecore': '', 'merchant_edit_anywhere_default_pricing': '', 'credit_as_a_service_enabled': '', 'checkout_link_expiration': '7', 'prequal_enabled': '', 'prequal_enabled_hidden': 'false', 'lto_prequal_enabled': '', 'lto_prequal_enabled_hidden': 'false', 'is_postqual_enabled': '', 'is_postqual_enabled_hidden': 'false', 'multi_use_prequal_enabled': '', 'multi_use_prequal_enabled_hidden': 'false', 'prequal_expiration_days': '1', 'prequal_min_bound': '', 'prequal_max_bound': '', 'is_ada_compliant': '', 'cart_logo_url': '', 'privacy_policy_url': '', 'refund_policy_url': '', 'terms_and_conditions_url': '', 'shopify_store': '', 'shopify_access_token': '', 'affirm_txn_fee_pct': '0.029900', 'fee_waived': '', 'fee_waiver_rate': '0.000000', 'fee_waiver_end_date': '2000-01-01', 'street1': '', 'street2': '', 'city': '', 'region1_code': '', 'postal_code': '', 'vcn_enabled': '', 'vcn_offline': '', 'affiliate_active': '', 'show_card_for_returns': '', 'include_in_buy_search': '', 'featured': '', 'n_allowed_vcn_auths': '32767', 'secure_confirm_checkout_response': '', 'test_card_number': '4111111111111111', 'landing_page_url': '', 'assets_base_url': '', 'vcn_app_priority': '0', 'logo_url': '', 'void_on_full_auth_reversal': '', 'instructions': '', 'ignore_zero_dollar_auth': '', 'platform': 'None', 'product_type': 'Affirm Anywhere', 'cool_off_policy': 'None', 'creation_origin': 'None', 'prequal_financing_program': '', 'card_product_identifier': 'None'}}
# new_config = updateConfig(old_config, update, 'merchant-conf')

# for i in new_config['merchant-conf']:
# 	if new_config['merchant-conf'][i] == old_config['merchant-conf'][i]:
# 		print(i)
# 		print(new_config['merchant-conf'][i])
# 		print(old_config['merchant-conf'][i])
# 	else:
# 		print('right')
