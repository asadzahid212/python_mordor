# Initial setup:
1. Clone / download the contents of this repo
1. Open the folder in Terminal (use your favorite method; optional method below)
	1. Open folder in Finder
	1. Go one folder up (so that you can see the folder `python_mordor-master` as a folder and can right-click it)
	1. Right-click `python_mordor-master`, select `New terminal at folder`
1. In Terminal, type `bash setup.sh`
	1. This will run a series of terminal commands. See the commands below (or open in a text editor) for troubleshooting:
```python3 -m venv venv
source venv/bin/activate
pip3 install -r requirements.txt
```
You now have a virtual environment for Python with all the requirements installed.

---
# Overview - what to expect
Each of these programs serves a distinct function. Use the following programs as a choose-your-own-adventure of what you want to create / configure. Each program will have an explicit input and subsequent action.

Each program will have a template input CSV, with the name `csvs/<folder-name>.csv`. The required fields will be included in the template. Anything not included will not be updated. If you want to update an incremental field, you will need to follow the below instructions.

## Adding incremental fields to a CSV
**Key context**: See the #Details section below for info on how the script is written and why these steps need to be taken.

**Steps to take**:

*Part 1*
- Open the Mordor page you are trying to programmatically update.
- Right-click the field you want updated and select `Inspect`.
- Within the HTML, you'll see an `<input>` element; find its `id` attribute. 
- Copy the `id` value (eg: for `id="merchant_name"`, we want `merchant_name`) and paste it as an incremental column header in the CSV for the script you are running.

*Part 2*
- With the `Network` tab in the inspector tool open, submit the form with the desired value. 
- Under the `Payload` section of the `Network` tab, look for the `id` value you copied earlier. (In most cases, this will have a `Form Data` section)
- Copy the corresponding value in the request (eg: `merchant_name: Pete's Snack Shack`).
- Paste this value in the CSV in the corresponding column for each row you want this value used.

## Setup for running any program
>Needs to be done any time you run a program; only needs to be done once for an active session
1. Open `python_mordor` in Terminal (right-click folder in Finder and click `New Terminal at Folder`)
1. In browser, open a fresh merchant Mordor page (eg click [this link](https://www.affirm.com/mordor/debugapp/merchants/umbrella/0DIN8RVY6UHAK9H0)). 
	1. Open the inspector tool. Select the `Application` section. 
	1. Select `Cookies`. 
	1. Search for `admin_session` (**NOT** `session`). Select `admin_session`. 
	1. Triple-click to select the whole value in `Value`. Copy this value.
1. In terminal, type the following, with the copied cookie value from the browser substituted in: `export SESSION_ID=<admin_session_cookie>`, press enter
1. Type `source venv/bin/activate`, press enter

>Now your environment is ready - you'll need to set the `SESSION_ID` every time you: a) close terminal and reopen, or b) disconnect from VPN and reconnect. This is because in `a)`, the environment variable gets reset. In `b)` the Mordor session resets and so the cookie is no longer valid and will not authenticate you into Mordor.

---
# Programs available:
## create-merchants
* **Input**: Fill out and save template in `csvs/create-merchants.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: True. `Merchant Info` section from Mordor.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 create-merchants/main.py`, press enter
1. If no errors, open the `python_mordor/csvs` folder and open `csvs/finished_create-merchants.csv` - you'll find the new merchant_aris prepended in a column to the left.

## mordor-config
* **Input**: Fill out and save template in `csvs/mordor-config.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: True. `Merchant Config` section from Mordor.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 mordor-config/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## add-to-umbrella
* **Input**: Fill out and save template in `csvs/add-to-umbrella.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 add-to-umbrella/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## enable-keys
* **Input**: Fill out and save template in `csvs/enable-keys.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 enable-keys/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## disable-keys
* **Input**: Fill out and save template in `csvs/disable-keys.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 disable-keys/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## landing-page
* **Input**: Fill out and save template in `csvs/landing-page.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 landing-page/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## create-sms
* **Input**: Fill out and save template in `csvs/create-sms.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 create-sms/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## delete-sms
* **Input**: Fill out and save template in `csvs/delete-sms.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 delete-sms/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.

## make-qrcodes
> **Important**: This pulls from the SMS codes in the merchant's SMS configuration. *Be sure to complete the `create-sms` flow before running this program.*
* **Input**: Fill out and save template in `csvs/make-qrcodes.csv` (do not change filename).
* **Can [add columns](#adding-incremental-fields-to-a-csv)?**: False.
* **How to run**:
*After running the [default setup](#setup-for-running-any-program)*
1. Type `python3 make-qrcodes/main.py`, press enter
1. If no errors, spot check some ARIs, but otherwise you should be good.


# Add'l details
## How does it work?
The script is able to update / act on Mordor by functionally mimicking a web browser. It hits the same endpoint that your browser does, with the same headers (as necessary) and authentication (a cookie defining your session in the browser). 

## How do you know how to define the HTTP requests so that they're ingested properly by Mordor?
Functionally, interacting with Mordor in the browser is just prompting the browser to make HTTP requests to Mordor's endpoints (affirm.com/debugapp/merchants... etc). If you open the inspector tool --> network tab in the browser and submit a form in Mordor, you'll see the requests that are made. These scripts mirror those requests.