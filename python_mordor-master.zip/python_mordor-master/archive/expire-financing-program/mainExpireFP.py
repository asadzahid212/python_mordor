from getFinancingPrograms import getFinancingPrograms
from expireFinancingProgram import expireFinancingProgram

def mainExpireFP(programs):
	# programs = getFinancingPrograms('expireFPCSV.csv')
	programs = programs
	for i in programs:
		expireFinancingProgram(programs[i])