#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from bs4 import BeautifulSoup
import datetime

def expireFinancingProgram(fp):
	print(fp)
	switchboard_ari = fp['switchboard_ari']
	if fp['expiration'] == '':
		now = datetime.datetime.now().__str__()
		expiration = now[:now.find('.')]
	else:
		expiration = fp['expiration']

	data = {
		'switchboard_ari':switchboard_ari,
		'expiration':expiration
		}
	#data = str(fp).replace("'","").replace(", ","\n").replace("}","").replace("{","")
	print('data')
	print(data)
	url = 'https://www.affirm.com/mordor/debugapp/financing/set_expiration'
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	res = requests.request(url=url, method=method, headers=headers, data=data)
	if res.status_code != 200:
		print('ERROR')
	
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	soup = BeautifulSoup(res.text, 'html.parser')
	all_alerts = []
	alerts = soup.find_all(class_="alert-danger")
	alerts2 = soup.find_all(class_="alert-error")
	all_alerts = [alerts, alerts2]
	print(all_alerts)
	if all_alerts != [[],[]] or "affirm.com/mordor/debug" not in res.url:
		print(alerts)
		print(res.url)
		print("affirm.com/mordor/debug" not in res.url)
		# input('what')

	return True

