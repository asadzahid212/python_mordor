from getRules import getRules
from createRule import createRule
import json

def oneOff(rules=''):
	rules = getRules('rulesCSV.csv')
	print(rules)
	for rule in rules:
		print(json.dumps(rule, indent=2))
		# input('does this fprule look right?')
		success = createRule(rules[rule])
		if success:
			print("sucessfully created rule")
		else:
			print('rule already existed with that name')

oneOff()