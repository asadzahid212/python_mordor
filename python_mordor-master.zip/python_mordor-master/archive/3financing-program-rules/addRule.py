#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from findFpRuleAri import findFpRuleAri
import datetime

def addRule (merchant_ari, rule):
	name = rule['name']
	priority = rule['priority']
	financing_program_external_name = rule['financing_program_external_name']
	if rule['start_date'] != '':
		start_date = rule['start_date']
	else:
		now = datetime.datetime.now().strftime("%m-%d-%Y, %I:%M%p")
		start_date = now
	end_date = rule['end_date']
	experiment_name = rule['experiment_name']

	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/financing_program_rules/' % (merchant_ari)
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {
		'name':name,
		'priority':priority,
		'financing_program_external_name':financing_program_external_name,
		'start_date':start_date,
		'end_date':end_date,
		'experiment_name':experiment_name
	}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	print(data)
	if res.status_code != 200:
		print('ERROR')
	file_object = open("mynewupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	print(res.text)
	rule_ari = findFpRuleAri(res.text, name)

	return rule_ari 

