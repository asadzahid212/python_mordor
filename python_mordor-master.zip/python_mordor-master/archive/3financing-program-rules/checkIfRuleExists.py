from getRulesHTML import getRulesHTML
from bs4 import BeautifulSoup

def checkIfRuleExists(rule):
	print(rule)
	rule_name = rule['name']
	html_doc = getRulesHTML(rule['merchant_ari'])

	soup = BeautifulSoup(html_doc, 'html.parser')
	aris = soup.find_all(id="ari")
	print('rule_name: ' + rule_name)
	print('aris: ' + str(aris))

	rule_exists = False
	for ari in aris:
		name = ari.parent.find(id="name")['value']
		print('name: ' + str(name))
		if rule_name == name:
			rule_exists = True
	return rule_exists