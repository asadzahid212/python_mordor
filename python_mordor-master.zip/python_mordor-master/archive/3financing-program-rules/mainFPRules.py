from getRules import getRules
from createRule import createRule
import json

def mainFPRules(rules):
	rules = rules #getRules('rulesCSV.csv')
	for i in rules:
		merchant = rules[i]
		for k in merchant:
			print(json.dumps(merchant, indent=2))
			# input('does this fprule look right?')
			success = createRule(merchant[k])
			if success:
				print("sucessfully created rule")
			else:
				print('rule already existed with that name')