#in: JSON of format:
"""
{
	name: "",
	priority: 1,
	financing_program_external_name: "",
	start_date: "",
	end_date: '',
	experiment_name: ''
}
"""
from addRule import addRule
from setRule import setRule
from checkIfRuleExists import checkIfRuleExists

def createRule(rule):
	exists = checkIfRuleExists(rule)
	if exists:
		return False
	merchant_ari = rule['merchant_ari']
	rule_ari = addRule(merchant_ari, rule)
	setRule(merchant_ari, rule, rule_ari)
	return True