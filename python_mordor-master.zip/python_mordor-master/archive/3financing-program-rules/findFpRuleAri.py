#in: html from financing rule creation, name of current one
#out: the ari of the relevant financing program
from bs4 import BeautifulSoup

def findFpRuleAri(html_doc, rule_name):
	soup = BeautifulSoup(html_doc, 'html.parser')
	aris = soup.find_all(id="ari")
	print('rule_name: ' + rule_name)
	print('aris: ' + str(aris))
	goal_ari = ''
	for ari in aris:
		name = ari.parent.find(id="name")['value']
		print('name: ' + str(name))
		if rule_name == name:
			goal_ari = ari['value']
	# input('the goal ari is: ' + goal_ari)
	return goal_ari
