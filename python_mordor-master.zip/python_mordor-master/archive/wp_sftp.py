import paramiko

client = paramiko.SSHClient()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect("transfer.stage.warby.io", username="affirm", password="", pkey=None, port=22)
print(client)
print(client.open_sftp())

