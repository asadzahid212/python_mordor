import sys
sys.path.insert(1, '../shared')

from getCSVDetails import getCSVDetails
from replaceFP import replaceFP

def mainReplaceFPs():
	FPs = getCSVDetails('replaceFPsCSV.csv')
	bind_anyway='n'
	for index in FPs:
		merchant_ari = FPs[index]['merchant_ari']
		financing_program_external_name = FPs[index]['financing_program_external_name']
		new_fp_internal_name = FPs[index]['new_fp_internal_name']
		ends_at = FPs[index]['ends_at']
		merchant_default = FPs[index]['merchant_default']
		# input(merchant_default)
		bind_anyway = replaceFP(merchant_ari=merchant_ari, financing_program_external_name=financing_program_external_name,new_fp_internal_name=new_fp_internal_name, ends_at=ends_at, bind_anyway=bind_anyway, merchant_default=merchant_default)

mainReplaceFPs()