
#!/usr/bin/env python
import snowflake.connector

def getOldSwitchboard(financing_program_external_name, merchant_ari):
	ctx = snowflake.connector.connect(
		user='peter.durlacher@affirm.com',
		authenticator='externalbrowser',
	    account='affirmuseast.us-east-1.privatelink'
	    )
	cur = ctx.cursor()
	sql = "select ari, merchant_default from users.financingprogramswitchboard where merchant_ari = '%s' and financing_program_external_name = '%s' and (ends_at is null or ends_at > current_date);" % (merchant_ari, financing_program_external_name)
	try:
		cur.execute(sql)
		# one_row = cur.fetchone()
		# print("printing one_row")
		# print(one_row)
		# print('printing one_row[0]')
		# print(one_row[0])
		res_sql = cur.fetchall()
		print("printing res_sql")
		print(res_sql)
		
		if len(res_sql) > 0:
			ari = res_sql[0][0]
			merchant_default = res_sql[0][1]
			if merchant_default == 0:
				merchant_default = 'False'
			else:
				merchant_default = 'True'
			res = {
			"ari": ari,
			"merchant_default": merchant_default
			}
			res['success'] = True
			return res
		else:
			print(sql)
			res = {}
			res['success'] = False
			return res
			
	finally:
		cur.close()
		ctx.close()
	
	
	
	
	
	