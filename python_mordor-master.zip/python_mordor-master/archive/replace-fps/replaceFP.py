import sys
sys.path.insert(1, '../2add-financing-program')
sys.path.insert(1, '../expire-financing-program')

from addFinancingProgram import addFinancingProgram
from expireFinancingProgram import expireFinancingProgram

from getOldSwitchboard import getOldSwitchboard

def replaceFP(merchant_ari, financing_program_external_name, new_fp_internal_name,ends_at, bind_anyway='n', merchant_default="unknown"):
	switchboard_to_expire = getOldSwitchboard(financing_program_external_name, merchant_ari)
	print(merchant_ari)
	print(financing_program_external_name)
	print(new_fp_internal_name)
	print(switchboard_to_expire)
	print(bind_anyway)
	# input('looking good?')
	if switchboard_to_expire['success']:
		expireFinancingProgram({
			"switchboard_ari": switchboard_to_expire['ari'],
			"expiration":""
			})
		if new_fp_internal_name != '':
			fp = {
			"starts_at":"",
			"ends_at":ends_at,
			"merchant_default": switchboard_to_expire['merchant_default'],
			'financing_program_name':new_fp_internal_name,
			'financing_program_external_name':financing_program_external_name,
			}
			print(fp)
			addFinancingProgram(merchant_ari, fp, skip_config_alert='y')
		else:
			print('no internal fp to replace - just expired old one then')
		# input('fp look good?')
	elif bind_anyway == 'y':
		if new_fp_internal_name != '':
			# input(merchant_default)
			if merchant_default == 'unknown':
				merchant_default = input("should the program I'm binding anyway be set as default? True/False here's the fp: " + new_fp_internal_name)
				if merchant_default == 'y':
					merchant_default = True
				else:
					merchant_default = False

			fp = {
			"starts_at":"",
			"ends_at":"",
			"merchant_default": merchant_default,
			'financing_program_name':new_fp_internal_name,
			'financing_program_external_name':financing_program_external_name,
			}
			# input(fp)
			print(fp)
			addFinancingProgram(merchant_ari, fp, skip_config_alert='y')
			# input('WE TRIED')
		else:
			print('no internal fp to replace - just expired old one then')
	else:
		bind_anyway = input("There's no FP with that external name. Should I just bind all new fps even without anything to disable? y/n")
		if bind_anyway == 'y':
			replaceFP(merchant_ari, financing_program_external_name, new_fp_internal_name, ends_at, bind_anyway=bind_anyway, merchant_default=merchant_default)
	return bind_anyway

