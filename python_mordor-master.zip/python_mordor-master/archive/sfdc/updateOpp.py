import requests
import os
import json
from getConfirmationToken import getConfirmationToken

def updateOpp(entityID, updates):
	url = 'https://affirm.my.salesforce.com/ui/common/InlineEditEntitySave'
	method = 'POST'
	Cookie = 'BrowserId=ADlqoP-EEeqYPBtbvbyl_w; BrowserId_sec=ADlqoP-EEeqYPBtbvbyl_w; _ga=GA1.2.480848234.1601099798; s_ecid=MCMID%7C60520521056307804453350886507404951652; oinfo=c3RhdHVzPUFjdGl2ZSZ0eXBlPUVudGVycHJpc2UrRWRpdGlvbiZvaWQ9MDBERTAwMDAwMDBlOGVt; autocomplete=1; oid=00DE0000000e8em; web_core_geoCountry=us; web_core_geoRedirected=true; optimizelyEndUserId=oeu1602598840576r0.9293594727887571; _cs_c=1; _cs_id=81d6cf38-bb31-a192-da53-c038fe6ffa19.1602598842.1.1602598842.1602598842.1.1636762842379; coveo_visitorId=9bbeb3bc-1fae-4250-8235-614f1ec2cd64; _gcl_au=1.1.77456096.1612480409; AMCVS_8D6C67C25245AF020A490D4C%40AdobeOrg=1; disco=4X:00DE0000000e8em:0050y00000EPVq2:1; sid_Client=y00000EPVq20000000e8em; _gid=GA1.2.1426570049.1615500816; AMCV_8D6C67C25245AF020A490D4C%40AdobeOrg=-1891778711%7CMCIDTS%7C18698%7CMCMID%7C60520521056307804453350886507404951652%7CMCAAMLH-1616000468%7C9%7CMCAAMB-1616105616%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1615508016s%7CNONE%7CMCAID%7CNONE%7CMCSYNCSOP%7C411-18539%7CvVersion%7C2.4.0; webact=%7B%22l_vdays%22%3A2%2C%22l_visit%22%3A1615500815910%2C%22session%22%3A1615562283724%2C%22l_search%22%3A%22%22%2C%22l_dtype%22%3A%22SFDC%20Network%22%2C%22l_page%22%3A%22SFDC%3Aus%3Alogin%22%2C%22counter%22%3A105%2C%22pv%22%3A1%2C%22f_visit%22%3A1601099797831%2C%22seg%22%3A%22customer%3Aus%22%2C%22d%22%3A%2270130000000sUW0%22%2C%22customer%22%3A1601481476354%7D; OptanonConsent=isIABGlobal=false&datestamp=Fri+Mar+12+2021+07%3A18%3A03+GMT-0800+(Pacific+Standard+Time)&version=5.11.0&landingPath=https%3A%2F%2Fc.salesforce.com%2Flogin-messages%2Fpromos.html&groups=1%3A1%2C3%3A1%2C4%3A1&hosts=; sfdc_lv2=KxG83Hf/bH4CLEnIB4xFtY3/DucJjAJZKDBvX6U+MpX+A7ZEfucWtAoVVCGtAc8NM=; sid=00DE0000000e8em!ARkAQD_ickmB.41MlX8yvaqRid_3_L97rt3ztuaUHBmiQojfNFz8vMUF_PWDzIG_XiYqHJoiNja93qmAvoyc5PaABxZLNLcS; clientSrc=135.180.41.126; QCQQ=2n1VGTSM0AA; sfdc-stream=!cOAbnDgqYCANVP/f3ulYR+km/HxnTMJ4xIwLV+TCUIbIyDQ3BH8vA83pamZ7wft4zgdI39BcNz+J7w==; SwitchToClassic=1615593203384'
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': Cookie,
	        'Host': 'affirm.my.salesforce.com',
	        'Origin': 'https://affirm.my.salesforce.com',
			'Pragma': 'no-cache',
			'Referer': 'https://affirm.my.salesforce.com/0014X00002JHvxX',
			'Sec-Fetch-Dest': 'empty',
			'Sec-Fetch-Mode': 'cors',
			'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 11_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.192 Safari/537.36',
			'X-Requested-With': 'XMLHttpRequest',
	      }
	_CONFIRMATIONTOKEN = getConfirmationToken(entityId)
	data = {'entityId': '0060y00001F5GAm',
			'_CONFIRMATIONTOKEN':_CONFIRMATIONTOKEN,
			'save': '1',
			}
	data.update(updates)
	res = requests.request(url=url, method=method, headers=headers, data=data)
	# print(data)
	if res.status_code != 200:
		print('ERROR')
	print(res.text)
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	return True
updateOpp()