#in: JSON of format:
"""
{
	name: "",
	priority: 1,
	financing_program_external_name: "",
	start_date: "",
	end_date: '',
	experiment_name: ''
}
"""
from checkUmbrella import checkUmbrella
import os
import requests

def createUmbrella(merchant):
	data = {}
	for key in merchant:
		data[key] = merchant[key]

	url = 'https://www.affirm.com/mordor/debugapp/merchants/umbrella'
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }

	res = requests.request(url=url, method=method, headers=headers, data=data)
	merchant_ari = res.url[res.url.find('umbrella')+len('umbrella')+1:]
	print(merchant_ari)
	# k = 0
	# for i in merchant_ari:
	# 	if merchant_ari[k] == '/':
	# 		merchant_ari = merchant_ari[0:k] + merchant_ari[k+1:]
	# 	k+=1
	print(data)
	if checkUmbrella(merchant_ari) == False:
		input('the merchant ari is..: ' + merchant_ari)
	else:
		print('the merchant ari is!: ' + merchant_ari)
	if res.status_code != 200:
		print('ERROR')
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()



	return merchant_ari