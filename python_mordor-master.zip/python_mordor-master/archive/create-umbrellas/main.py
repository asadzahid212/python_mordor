from getUmbrella import getUmbrella
from createUmbrella import createUmbrella
from writeUmbrella import writeUmbrella

merchants = getUmbrella('merchantCSV.csv')
merchant_aris = ['merchant_ari']
for i in merchants:
	merchant_ari = createUmbrella(merchants[i])
	merchant_aris.append(merchant_ari)
writeUmbrella('merchantCSV.csv', merchant_aris)