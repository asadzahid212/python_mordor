#in: file name
#out: JSON of structure:
"""
{
	0: {
		'ari':''
	}
}
"""
import csv
def writeUmbrella(file_name, merchant_aris):
	with open(file_name, newline='') as csvfile:
		csvreader = csv.reader(csvfile, delimiter=',')
		with open('finishedMerchantCSV.csv', 'w') as writefile:
			csvwriter = csv.writer(writefile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
			columns = []
			row_num = 0
			for row in csvreader:
				print(row)
				row.insert(0, merchant_aris[row_num])
				row_num += 1
				csvwriter.writerow(row)
	return True