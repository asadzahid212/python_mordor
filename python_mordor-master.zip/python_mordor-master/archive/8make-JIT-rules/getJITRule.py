#in: file name
#out: JSON of structure:
"""
{
	0: {
		'ari':''
	}
}
"""
import csv
def getJITRule(file_name):
	with open(file_name, newline='') as csvfile:
		csvreader = csv.reader(csvfile, delimiter=',')
		updates = {}
		columns = []
		row_num = 0
		for row in csvreader:
			print(row)
			if row_num == 0:
				for col in row:
					columns.append(col)
			else:
				updates[row_num] = {}
				col_num = 0
				for col in row:
					updates[row_num][columns[col_num]] = col
					col_num += 1
			row_num += 1
	return updates