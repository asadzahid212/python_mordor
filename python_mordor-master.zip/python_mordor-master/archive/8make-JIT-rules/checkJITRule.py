#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
import psycopg2
from bs4 import BeautifulSoup

def checkJITRule(merchant_ari, data, timing, res=None):
	valid = False
	if timing == 'before':
		password = os.environ.get('DB_PW')
		con=psycopg2.connect(dbname= 'affirm', host='sherlock.team.affirm.com', port= '5439', user= 'peterdurlacher', password=password)
		cur = con.cursor()
		sql = "select auth_decision_identifier_type, auth_decision_identifier_value, transaction_request_field, values, description, rule_type, value_type, network from virtual_cards_authrule where auth_decision_identifier_value = '%s';" % (merchant_ari)

		cur.execute(sql)

		res_sql = cur.fetchall()
		auth_decision_identifier_type = data['auth_decision_identifier_type']
		auth_decision_identifier_value = data['auth_decision_identifier_value']
		transaction_request_field = data['transaction_request_field']
		values = data['values']
		description = data['description']
		rule_type = data['rule_type']
		value_type = data['value_type']
		network = data['network']

		
		for row in res_sql:
			if row == (auth_decision_identifier_type, auth_decision_identifier_value, transaction_request_field, values, description, rule_type, value_type, network):
				valid = True
			else:
				continue
		if not valid:
			print('no rule yet!')
	elif timing == 'after':
		try:
			res = json.loads(res)
		except:
			print(res)
			input('res not jsonable!`')
		for key in data:
			if key == 'updated':
				continue
			if res['auth_rule'][key] == data[key]:
				continue
			else:
				print(res)
				print(data)
				valid = False
				input("doesn't match!")
		valid = True
		print('JIT rule looks good!')
	return valid
	