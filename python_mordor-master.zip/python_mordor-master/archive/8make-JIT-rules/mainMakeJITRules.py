from getJITRule import getJITRule
from createJITRule import createJITRule


#REWRITE: this should just pull from test card and try to create JIT rules that way
def mainMakeJITRules(JITRules):
	JITRules = JITRules #getJITRule('JITCSV.csv')
	for i in JITRules:
		print(JITRules[i])
		# input('does this omni/landing_page look right?')
		runByNetwork(JITRules[i])