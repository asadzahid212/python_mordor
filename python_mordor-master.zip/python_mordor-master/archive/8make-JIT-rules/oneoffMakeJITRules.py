from getJITRule import getJITRule
from runByNetwork import runByNetwork

def oneoffMakeJITRules():
	JITRules = getJITRule('JITCSV.csv')
	for i in JITRules:
		print(JITRules[i])
		# input('does this omni/landing_page look right?')
		runByNetwork(JITRules[i])


oneoffMakeJITRules()