from createJITRule import createJITRule

def runByNetwork(JITRule):
	for network in ['mastercard','visa']:
		createJITRule(JITRule, network)
	return True