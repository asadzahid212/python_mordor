#in: JSON of format:
"""
{
	name: "",
	priority: 1,
	financing_program_external_name: "",
	start_date: "",
	end_date: '',
	experiment_name: ''
}
"""
from checkJITRule import checkJITRule
import json
import os
import requests

def createJITRule(JITRule, network):
	print('createjitrule')
	merchant_ari = JITRule['merchant_ari']
	values = JITRule['name']
	description = "Name locking: " + values
	rule_type = 'allow'
	status = 'enabled'
	transaction_request_field = 'name'
	updated = ''
	value_type = 'regex'
	auth_decision_identifier_type = 'merchant_ari'
	auth_decision_identifier_value = merchant_ari
	network = network
	

	url = 'https://www.affirm.com/mordor/debugapp/virtual_cards/jit_auth_controls/auth_rules'
	data = json.dumps({
	'auth_decision_identifier_type': auth_decision_identifier_type,
	'auth_decision_identifier_value': auth_decision_identifier_value,
	'description': description,
	'rule_type' : rule_type,
	'status': status,
	'transaction_request_field': transaction_request_field,
	'updated': updated,
	'value_type': value_type,
	'values': values,
	'network': network
	})
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	session = '.eJwtkclO40AABX9l5DMHL2OEkTgQvMUk7el9uSDH7Ukn3bFNbCAY8e8TpDnV5akOr7681jTOdf2-8-6_vNPf5ge_dt69x4Uj0GrbCfaJimBEFPhNNFbImrEtxlRZB-VickAcpGG1UPsRqjB4a0v9ThkjgBhJlzyVfu6zI2iQM6-KsIgeXcGtnmS4D2DE8C7Tw4bbD5JVExard-lXKeDxBBwzNUVCMziDAsykqCQuLlfPY9xxF9IsWHbhDJDT6zbNfBo62PLgllKzZk4TlTssRV4SG2Nt2Se0qsa9Y3hBzzrQMc1cT7MR0h5GG5YzUo4ZFcDHi6pRVG3wCRzVCfRiqZ46nsyEurVYzKCCBKAQ_JHMrTaEkZrHZxCAdNcD0xRGcHuZKatYW-RyS_Oa0UujA7WtmQogTyiGDw_e9_eN1w793F3ml-Z8uN5dlqpK-VOGhcTiFmXejfc2deefHG7YH_qXqZumw9D_n8Pkrl793j6GoE7u0Bpcjf8A1uWY2Q.Emj74Q.ZyKixpXvIPMzsMZnT1J_nO8qXkg'
	merchant_session = 'eyJsb2dpbl9zZXNzaW9uX2FyaSI6IkhYUUpFWE1DS0U1TkMwTkgifQ.Emj74Q.RDE2u23j8DOqo2UO2ir9EMhIUno'
	USER_ARI_SIGNED_COOKIE = 'IjM5NzYtNzE3My1ZUUpKIg.EmYdzA.KxZWBuWH4vlgvLyEa2bcr5lrFNM'
	print(session_id)
	print(data)
	cookie = 'admin_session=%s; session=%s; merchant_session=%s; USER_ARI_SIGNED_COOKIE=%s' % (session_id, session, merchant_session, USER_ARI_SIGNED_COOKIE)
	print(cookie)
	headers = {
			'accept': '*/*',
			'accept-encoding': 'gzip, deflate, br',
			'accept-language': 'en-US,en;q=0.9',
			'cache-control':'no-cache',
	        'Content-Type': 'application/json',
	        'origin':'https://www.affirm.com',
	        'pragma': 'no-cache',
	        'sec-fetch-dest': 'empty',
	        'sec-fetch-mode': 'cors',
	        'sec-fetch-site': 'same-origin',
	        'cookie': cookie,
	        'referer': 'https://www.affirm.com/mordor/debugapp/virtual_cards/jit_auth_controls?auth_decision_identifier_type=merchant_ari&auth_decision_identifier_value=%s' % (merchant_ari)
	      }

	rule_exists = checkJITRule(merchant_ari, json.loads(data), 'before')
	if rule_exists:
		print("rule already exists")
		return True
	res = requests.request(url=url, method=method, headers=headers,data=data)

	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	if res.status_code != 200:
		print(res.text)
		input('ERROR')
	checkJITRule(merchant_ari, json.loads(data), 'after', res=res.text)

	return True