from pullOneTemplate import pullOneTemplate
from alignTemplateDataWithDataFormat import alignTemplateDataWithDataFormat
import json

def checkTemplate(expected_template):
	live_template = pullOneTemplate(expected_template['id'])
	live_template = alignTemplateDataWithDataFormat(live_template)
	print(json.dumps(live_template,indent=2))
	print(json.dumps(expected_template,indent=2))
	validated = True
	for key in live_template:
		if key not in expected_template:
			validated = False
			print('Looks like it might be borked!')
			print(key)
			input('this key is the problem, hit enter to continue')
	return validated
