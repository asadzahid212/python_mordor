from pullTemplates import pullTemplates
from addChangesToTemplate import addChangesToTemplate
from updateTemplate import updateTemplate

def updateMerchant(merchant_ari, promo):
	all_templates_for_merchant = pullTemplates(merchant_ari)

	for template in all_templates_for_merchant:
		template = addChangesToTemplate(template, promo)
		success = updateTemplate(template)

	return success