import sys 
sys.path.insert(1, '../shared')
from getCSVDetails import getCSVDetails 
from updateMerchant import updateMerchant
import json

#So here we need to run through the sheet
#Each line in the sheet represents one change
# that needs to apply to all promos across
# a single merchant. So it passes the merchant to 
# updateMerchant which then runs through all the 
# templates for that merchant and updates them

def mainUpdatePromos(promos):
	# input('WAIT -- 7/6/20')
	promos = getCSVDetails('promosCSV.csv')
	print(json.dumps(promos, indent=2))
	for promo in promos:
		merchant_ari = merchant['merchant_ari']
		promo.pop('merchant_ari')
		# input('does this FP look right?')
		success = updateMerchant(merchant_ari, promo)
		if success:
			print('updated a promo!')
		else:
			input('not updated :(')