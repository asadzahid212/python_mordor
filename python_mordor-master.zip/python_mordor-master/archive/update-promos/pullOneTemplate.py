#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import sys 
sys.path.insert(1, '../shared')
from saveResponse import saveResponse

import requests
import os
import json

def pullOneTemplate(template):
	template_id = template['id']

	url = 'https://www.affirm.com/api/templates/v1/%s' % (template_id)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }

	res = requests.request(url=url, method=method, headers=headers)
	
	saveResponse(res)
	template = json.loads(res.text)
	return template
