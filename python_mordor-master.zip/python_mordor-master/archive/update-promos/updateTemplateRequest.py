import json

def addChangesToTemplate(template, promo):
	#runs through the attributes from the sheet
	# and updates the corresponding attributes
	# in the template from mordor so that the 
	# request we send to mordor is the same as
	# what we got from mordor, with only the 
	# fields from the sheet updated
	#Specifically, we have to only update the 
	# aspects defined however deep into the 
	# object that should be the request
	"""
	for key in promo:
		update = json.loads(promo[key])
		for i in update:
			while type(update[i]) == dict:


		template[key] = promo[key]
"""
	return template
