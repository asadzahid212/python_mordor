#Removing any fields that are present in the response
# when GETing the template, but shouldn't be present
# in the request to PUT the new template
def alignTemplateDataWithDataFormat(template):
	to_pop = [
	'financing_program_name', 
	'bulk_update_options', 
	'default_footer_apr_text',
	'dropdown_options',
	'merchant_name',
	'id'
	]

	#Have to add back in a few keys that are needed to submit
	# that aren't in the template when GETing
	#And they are just pulled from elsewhere in the template we GET-ed
	to_add = {
	'copy_to_other_environment': 'false',
	'bulk_update_selectors': {
		"financing_programs": [template['financing_program_external_name']],
		"page_types": [template['page_type']],
		'states': [template['state']]
	}
	}

	for key in to_pop:
		template.pop(key)

	for key in to_add

	return template