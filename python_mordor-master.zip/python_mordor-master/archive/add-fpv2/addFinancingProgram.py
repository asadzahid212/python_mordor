#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from bs4 import BeautifulSoup
import datetime

def addFinancingProgram (merchant_ari, fp, skip_config_alert='n'):
	merchant_ari = merchant_ari
	# fp.pop('merchant_ari')
	if fp['start_date'] == '':
		now = datetime.datetime.now().isoformat()
		start_date = now[:now.find('.')] + 'Z'
		fp['start_date'] = start_date
	if fp['name'] == '':
		fp['name'] = 'placeholder_name'
	if fp['priority'] == '':
		fp['priority'] = 1
	if fp['is_active'] == '':
		fp['is_active'] = True
	else:
		fp['is_active'] = False
	if fp['is_default'] == '':
		fp['is_default'] = False
	else:
		fp['is_default'] = True
	if fp['rule_criteria'] == '':
		fp['rule_criteria'] = None

	created_by = fp['created_by']
	financing_program_v2_uuid = fp['financing_program_v2_uuid']	
	is_active = fp['is_active']
	is_default = fp['is_default']
	name = fp['name']
	priority = fp['priority']
	if is_default == True:
		priority = 50
	rule_criteria = json.loads(fp['rule_criteria'])
	start_date = fp['start_date']


	data = {
    "merchant_financing_program_rule": {
        "merchant_ari": merchant_ari,
        "created_by": created_by,
        "financing_program_v2_uuid": financing_program_v2_uuid,
        "is_active": is_active,
        "is_default": is_default,
        "name": name,
        "priority": priority,
        "rule_criteria": [rule_criteria],
        "start_date": start_date
    	}
    }
	#data = str(fp).replace("'","").replace(", ","\n").replace("}","").replace("{","")
	print('data')
	print(data)
	print(type(data))
	url = 'https://www.affirm.com/api/pricing/v1/rules/merchants/%s' % (merchant_ari)
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/json',
	        'Cookie': 'admin_session=' + session_id,
	        'Accept': '*/*',
	        'Accept-Encoding': 'gzip, deflate, br',
	        'Connection': 'keep-alive'
	      }
	data = data
	print(data)
	res = requests.request(url=url, method=method, headers=headers, json=data)
	print(res.json())
	if res.json()['message'] != "Create merchant financing program rule or experimental rule success":
		print('ERROR')
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	# soup = BeautifulSoup(res.text, 'html.parser')
	# all_alerts = []
	# alerts = soup.find_all(class_="alert-danger")
	# alerts2 = soup.find_all(class_="alert-error")
	# all_alerts = [alerts, alerts2]
	# print(all_alerts)
	# if all_alerts != [[],[]] or "affirm.com/mordor/debug" not in res.url:
	# 	print(alerts)
	# 	print(res.url)
	# 	print("affirm.com/mordor/debug" not in res.url)
	# 	proceed = ''
	# 	for alert in alerts:
	# 		if 'PREQUAL CONFIGURATION ALERT' in str(alert) and skip_config_alert == 'n':
	# 			proceed = input('should we accept? y/n')
	# 		else:
	# 			# proceed = 'y'
	# 			pass
	# 			# input('what')
	# 	if proceed == 'y':
	# 		fp['ignore_cutoffs'] = 'y'
	# 		addFinancingProgram(merchant_ari, fp)
	# 	skip = input('skip along past alert?')
	# 	if skip == 'y':
	# 		return True

	return True

