import sys
sys.path.insert(1, '../shared')

from getCSVDetails import getCSVDetails
from addFinancingProgram import addFinancingProgram
import json

def mainFP(programs):
	programs = getCSVDetails('FPv2CSV.csv')
	print(programs)
	for i in programs:
		program = programs[i]	
		merchant_ari = program['merchant_ari']
		print(json.dumps(program, indent=2))
		# input('does this FP look right?')
		addFinancingProgram(merchant_ari, program)
mainFP('')