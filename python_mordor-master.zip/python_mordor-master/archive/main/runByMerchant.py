import sys
sys.path.insert(1, '../1mordor-config')
sys.path.insert(1, '../2add-financing-program')
sys.path.insert(1, '../3financing-program-rules')
sys.path.insert(1, '../4landing-page')
sys.path.insert(1, '../5create-sms')
sys.path.insert(1, '../6enable-keys')
sys.path.insert(1, '../7get-onboarding-card')
sys.path.insert(1, '../8make-JIT-rules')
sys.path.insert(1, '../expire-financing-program')
sys.path.insert(1, '../9add-to-umbrella')
sys.path.insert(1, '../5-5disable-keys')

from mainConfig import mainConfig
from mainFP import mainFP
from mainFPRules import mainFPRules
from mainLandingPage import mainLandingPage
from mainSMS import mainSMS
from mainKeys import mainKeys
from mainExpireFP import mainExpireFP
from mainGetOnboardingCard import mainGetOnboardingCard
from mainMakeJITRules import mainMakeJITRules
from mainUmbrella import mainUmbrella
from mainDisableKeys import mainDisableKeys

def runByMerchant(settings):
	for merchant_ari in settings['keys']:
		config = {merchant_ari: settings['config'][merchant_ari]}
		financing_program = {merchant_ari: settings['financing_program'][merchant_ari]}
		financing_program_rules = {merchant_ari: settings['financing_program_rules'][merchant_ari]}
		landing_page = {merchant_ari: settings['landing_page'][merchant_ari]}
		sms = {merchant_ari: settings['sms'][merchant_ari]}
		keys = {merchant_ari: settings['keys']}
		umbrellas = {merchant_ari: settings['parent_ari'][merchant_ari]}

		#OPTIONAL: 
		# switchboard_ari = {merchant_ari: settings['expire_program'][merchant_ari] }
		# mainExpireFP(switchboard_ari)
		# mainUmbrella(umbrellas)
		mainDisableKeys(keys)
		mainConfig(config)
		# mainFP(financing_program)
		# mainFPRules(financing_program_rules)
		# mainLandingPage(landing_page)
		# mainSMS(sms, csv_to_update='csvs/all_settings.csv')
		# mainGetOnboardingCard(merchant_ari)		

		# mainKeys(keys)
		
		#idea here is to run this on last week's merchant_aris to make sure we have the JITRules from test cards
		#realistically, we should keep track of it all in the google doc. Yet to come
		# mainMakeJITRules(merchant_ari)
