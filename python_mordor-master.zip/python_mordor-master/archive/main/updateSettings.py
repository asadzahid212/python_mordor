"""
IN: JSON of:
{0: {
	"merchant_ari": merchant_ari,
	"config_preset": "audi",
	etc.
}}


OUT: JSON of:
{"sms":
	{0: 
	{merchant_ari: merchant_ari,
	financing_program: financing_program,
	etc
}}}

"""
from pullPreset import pullPreset
from cleanSettings import cleanSettings
import json

def updateSettings(all_settings):
	final_settings = {}
	for i in all_settings:
		setting = all_settings[i]
		merchant_ari = setting['merchant_ari']

		if setting['config_preset'] != '':
			#pull the preset
			final_settings[merchant_ari] = pullPreset(setting)
			print(json.dumps(final_settings[merchant_ari], indent=2))
			# input('DOES THIS look right?')
		else:
			#pull based on custom setup that should just match based on merchant_ari
			#todo: build support for this
			pass
	print("AKJNFKSJD")
	print(json.dumps(final_settings, indent=2))
	input('does it look right?')
	final_settings = cleanSettings(final_settings)
	return final_settings