import json

def cleanSettings(all_settings):
	print(json.dumps(all_settings, indent=2))
	# input('all settings before clean')
	new_settings = {"keys":[]}
	for merchant in all_settings:
		for key in all_settings[merchant]:
			new_settings[key] = {}
			if merchant not in new_settings['keys']:
				new_settings['keys'].append(merchant)
	print(json.dumps(new_settings, indent=2))
	# input('all settings after step 1')
	for merchant in all_settings:
		for key in all_settings[merchant]:
			new_settings[key][merchant] = all_settings[merchant][key][merchant]

	print("NEW SETTINGS::::")
	print(json.dumps(new_settings, indent=2))
	# input('afte')
	#input('eh?')
	return new_settings