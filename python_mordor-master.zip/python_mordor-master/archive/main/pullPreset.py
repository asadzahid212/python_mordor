import csv
import datetime
from getAll import getAll

def pullPreset(setting):
	print(setting)
	config_preset = setting['config_preset']
	fp_type = setting['fp_type']
	honeymoon = setting['honeymoon']
	sms_keyword = setting['sms_keyword']
	display_name = setting['display_name']
	display_name_prefix = setting['display_name_prefix']
	dealer_name = setting['dealer_name']

	instore_landing_page_url = setting['instore_landing_page_url']
	instore_landing_page_url.replace('/', '-')

	merchant_ari = setting['merchant_ari']
	#input(instore_landing_page_url)
	csvs = {
		"sms": "csvs/SMSCSV.csv",
		"landing_page": 'csvs/landingPageCSV.csv',
		"financing_program": 'csvs/FPCSV.csv',
		"financing_program_rules": 'csvs/FPRuleCSV.csv',
		"config": 'csvs/configCSV.csv', #for standard use
		# "config": 'csvs/configCSVterminate.csv',
		"expire_program": "csvs/expireFPCSV.csv",
		"parent_ari": "csvs/umbrellaCSV.csv"
		}

	new_setting = {}

	#{"sms": }
	for key in csvs:

		#{"sms": 
		#	0: {}
		#}
		new_setting[key] = {}
		new_setting[key][merchant_ari] = {}

		#{0: {
		# "merchant_ari":"",
		# "sms_keyword":"",
		# etc
		#}}
		presets_for_sheet = getAll(csvs[key])

		for i in presets_for_sheet:
			print(i)
			# input('THIS IS I')
			preset = presets_for_sheet[i]
			print('KEY IS: ' + key)
			print('PRESET IS: ' + str(preset))
			#check if the config_preset is auto
			if preset['config_preset'] == config_preset:
				#if it is, use that preset
				preset.pop('config_preset')
				
				if key == "sms":
					new_setting[key][merchant_ari] = preset
					if [sms_keyword, display_name, instore_landing_page_url, display_name_prefix] != ['','','','']:
						new_setting[key][merchant_ari]['sms_keyword'] = sms_keyword
						new_setting[key][merchant_ari]['instore_landing_page_url'] = instore_landing_page_url
						new_setting[key][merchant_ari]['display_name'] = display_name
						new_setting[key][merchant_ari]['display_name_prefix'] = display_name_prefix	
						new_setting[key][merchant_ari]['dealer_name'] = dealer_name			
						# input(new_setting)
					else:
						pass
				elif key == "landing_page":
					new_setting[key][merchant_ari] = preset
					new_setting[key][merchant_ari]['instore_landing_page_url'] = instore_landing_page_url
					# input(new_setting[key][merchant_ari])
				elif key == "financing_program":
					if preset['fp_type'] == fp_type:
						if preset['honeymoon'].lower() == 'True'.lower() and honeymoon.lower() == 'True'.lower():
							new_setting[key][merchant_ari][i] = preset
							now = datetime.datetime.now()
							ends_at = now + datetime.timedelta(days=100)
							ends_at = ends_at.isoformat()
							new_setting[key][merchant_ari][i]['ends_at'] = ends_at
							new_setting[key][merchant_ari][i].pop('fp_type')
							new_setting[key][merchant_ari][i].pop('honeymoon')
							new_setting[key][merchant_ari][i]['merchant_ari'] = merchant_ari
						elif preset['honeymoon'].lower() == 'True'.lower() and honeymoon.lower() != 'True'.lower():
							pass
						else:
							new_setting[key][merchant_ari][i] = preset
							new_setting[key][merchant_ari][i].pop('fp_type')
							new_setting[key][merchant_ari][i].pop('honeymoon')
							new_setting[key][merchant_ari][i]['merchant_ari'] = merchant_ari
						print(new_setting[key][merchant_ari][i])
						print(i)
						#input('right fp?')
					# else:
						# input("There was a row with no value in the 'fp_type' column, despite having a value in the 'config_preset' column. Please add a value and re-run, or it won't bind any FPs.")
				elif key == 'financing_program_rules':
					new_setting[key][merchant_ari][i] = preset
					new_setting[key][merchant_ari][i]['merchant_ari'] = merchant_ari
					print(new_setting[key][merchant_ari][i])
					if preset['honeymoon'].lower() == "TRUE".lower():
						now = datetime.datetime.now()
						ends_at = now + datetime.timedelta(days=100)
						ends_at = ends_at.strftime("%m-%d-%Y, %I:%M%p")
						new_setting[key][merchant_ari][i]['end_date'] = ends_at

				if key == 'config':
					new_setting[key][merchant_ari] = preset
				

				if key not in ['financing_program', 'financing_program_rules']:
					new_setting[key][merchant_ari]['merchant_ari'] = merchant_ari	
				print(key)
				# input()
				# input('the key is : '+ key)
				if key == 'expire_program':
					# input("'we're here")
					new_setting[key][merchant_ari]['switchboard_ari'] = setting['expire_program']
					new_setting[key][merchant_ari]['expiration'] = ''
		if key == 'parent_ari':
			print(setting[key])
			# input('IT IS PARENT ARI')
			new_setting[key][merchant_ari]
			new_setting[key][merchant_ari]['parent_ari'] = setting['parent_ari']
			new_setting[key][merchant_ari]['child_ari'] = merchant_ari

	print('NEW SETTING IS: ' + str(new_setting))
	#new_setting['merc'].append(merchant_ari)
	return new_setting	

"""
{"financing_program":{
	0: {
	merchant_ari: {
	0: {name: "",
	etc}
	1:
	}
	}
}}
"""
	
