
from getAll import getAll
from updateSettings import updateSettings

from runByMerchant import runByMerchant

all_settings = getAll('csvs/all_settings.csv')

"""
We want to get out of updateSettings the JSON of:
{"sms": {
	0: {
	"merchant_ari":merchant_ari
	eachofthesettingsforSMS
	}
	etc.
}}
"""
settings = updateSettings(all_settings)


"""
We want to pass to each of these the JSON of:
{0: {
	"merchant_ari":merchant_ari
	eachofthesettingsforSMS
	}
	etc.
}
"""
print(settings)
# input('wat)')

settings = runByMerchant(settings)




