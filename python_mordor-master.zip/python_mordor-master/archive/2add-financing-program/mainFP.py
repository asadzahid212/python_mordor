from getFinancingPrograms import getFinancingPrograms
from addFinancingProgram import addFinancingProgram
import json

def mainFP(programs):
	# input('WAIT -- 7/6/20')
	programs = programs #getFinancingPrograms('FPCSV.csv')
	print(programs)
	for merchant_ari in programs:
		merchant = programs[merchant_ari]
		for i in merchant:
			program = merchant[i]
			print(json.dumps(program, indent=2))
			# input('does this FP look right?')
			addFinancingProgram(merchant_ari, program)