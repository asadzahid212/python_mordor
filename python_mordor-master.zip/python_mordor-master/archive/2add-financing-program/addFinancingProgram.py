#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from bs4 import BeautifulSoup
import datetime

def addFinancingProgram (merchant_ari, fp, skip_config_alert='n'):
	merchant_ari = merchant_ari
	# fp.pop('merchant_ari')
	if fp['starts_at'] == '':
		now = datetime.datetime.now().isoformat()
		starts_at = now###
		fp['starts_at'] = starts_at

	data = 'financing_program_name: ' + fp['financing_program_name']+"\n" + \
        'financing_program_external_name: ' + fp['financing_program_external_name'] + "\n" + \
        'merchant_ari: ' + merchant_ari + "\n" + \
        'merchant_default: ' + fp['merchant_default'] + "\n" + \
        'starts_at: ' + fp['starts_at'] + "\n" + \
        'ends_at: ' + fp['ends_at']
	#data = str(fp).replace("'","").replace(", ","\n").replace("}","").replace("{","")
	print('data')
	print(data)
	url = 'https://www.affirm.com/mordor/debugapp/financing/bind_merchant_to_program'
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {'payload':data}
	if skip_config_alert == 'y':
		data['ignore_cutoffs'] = 'y'
	try:
		data['ignore_cutoffs'] = fp['ignore_cutoffs']
	except:
		pass

	res = requests.request(url=url, method=method, headers=headers, data=data)
	if res.status_code != 200:
		print('ERROR')
	else:
		pass
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	soup = BeautifulSoup(res.text, 'html.parser')
	all_alerts = []
	alerts = soup.find_all(class_="alert-danger")
	alerts2 = soup.find_all(class_="alert-error")
	all_alerts = [alerts, alerts2]
	print(all_alerts)
	if all_alerts != [[],[]] or "affirm.com/mordor/debug" not in res.url:
		print(alerts)
		print(res.url)
		print("affirm.com/mordor/debug" not in res.url)
		proceed = ''
		skip = ''
		for alert in alerts:
			if 'PREQUAL CONFIGURATION ALERT' in str(alert) and skip_config_alert == 'n':
				proceed = input('should we accept? y/n')
			elif 'MerchantHasOverlappingProgramWithSameName' or "MerchantHasOverlappingDefaultProgram" in str(alert):
				skip = 'y'
			else:
				# proceed = 'y'
				pass
				# input('what')

		if proceed == 'y':
			fp['ignore_cutoffs'] = 'y'
			addFinancingProgram(merchant_ari, fp)
		if skip != 'y':
			skip = input('skip along past alert?')
		if skip == 'y':
			return True

	return True

