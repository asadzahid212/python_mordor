from getFinancingPrograms import getFinancingPrograms
from addFinancingProgram import addFinancingProgram
import json

def mainFP():
	programs = getFinancingPrograms('FPCSV.csv')
	print(programs)
	for i in programs:
		program = programs[i]
		merchant_ari = program['merchant_ari']
		print(json.dumps(program, indent=2))
		print(merchant_ari)
		addFinancingProgram(merchant_ari, program)

mainFP()