import os
import requests

def updatePromo():
	

	url = 'https://www.affirm.com/api/templates/v1/5126225'
	method = 'PUT'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {"modal": {"html_footer": {
				"default_message": "A down payment may be required. Subject to eligibility check and approval. Payment options depend on your purchase amount. Estimated payment amount excludes taxes and shipping fees. Actual terms may vary. Payment options through Affirm are provided by these lending partners: {loan_originator_link}. Visit affirm.com/help for more info.",
				"custom_message": "this is a footer"
			}
			}
			}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	print(data)
	if res.status_code != 200:
		print('ERROR')
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()

	return "asdf"
updatePromo()

	"""


	{"term_sort_order":"term_length","merchant_ari":"ILO8VZZG7KV8Q0EM","loan_type":"classic","copy_to_other_environment":true,"page_type":"banner","bulk_update_selectors":{"financing_programs":["","test"],"page_types":["banner"],"states":["default"]},"modal":{"styles":{"color":null,"fontFamily":"'proxima-nova', sans-serif"},"terms_description":{"default_message":"","custom_message":null},"footer_apr_text":null,"tagline":{"default_message":"Rates from {apr_range}% APR.","custom_message":"{payment}/mo. based on a purchase price of {amount} at {apr}% APR for {term_length} months. Rates from {apr_range}% APR."},"html_footer":{"default_message":"A down payment may be required. Subject to eligibility check and approval. Payment options depend on your purchase amount. Estimated payment amount excludes taxes and shipping fees. Actual terms may vary. Payment options through Affirm are provided by these lending partners: {loan_originator_link}. Visit affirm.com/help for more info.","custom_message":null},"content_space_1":{"default_message":"quick_and_easy","custom_message":null},"button":{"default_message":"See if you qualify","custom_message":null},"content_space_2":{"default_message":"no_hidden_fees","custom_message":null},"headline":{"default_message":"Buy now, pay over time","custom_message":"Make easy monthly payments over {term_lengths} months"},"images":{"hero2x":null,"logo":null,"hero":null,"logo2x":null},"footer":{"default_message":"A down payment may be required. Subject to eligibility check and approval. Payment options depend on your purchase amount. Estimated payment amount excludes taxes and shipping fees. Actual terms may vary. Payment options through Affirm are provided by these lending partners: {loan_originator_link}. Visit affirm.com/help for more info.","custom_message":null},"description":{"default_message":"","custom_message":null}},"external_id":"promo_set_default_banner","state":"default","environment":"live","prequal_enabled":false,"ala":{"html_tagline":{"default_message":"Buy in monthly payments with {affirm_logo} on orders over {minimum_loan_amount}","custom_message":null},"tagline":{"default_message":"","custom_message":"Starting at {payment}/mo with {affirm_logo}"},"cta":{"default_message":"Learn more!","custom_message":"Learn more"},"cta_divider":". "},"financing_program_v2_uuid":null,"financing_program_external_name":""}


	"""