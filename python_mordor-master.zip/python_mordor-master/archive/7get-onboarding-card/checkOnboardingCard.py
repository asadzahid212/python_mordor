#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from bs4 import BeautifulSoup

def checkOnboardingCard(res_text):
	try:
		card = res_text['card']
	except:
		input('looks like the res_text is not uh good: ' + str(res_text))
	
	return True
