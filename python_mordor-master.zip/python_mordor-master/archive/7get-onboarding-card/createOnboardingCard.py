#in: JSON of format:
"""
{
	name: "",
	priority: 1,
	financing_program_external_name: "",
	start_date: "",
	end_date: '',
	experiment_name: ''
}
"""
from checkOmni import checkOmni
import os
import requests

def createOnboardingCard(onboardingCard, network):
	merchant_ari = onboardingCard['merchant_ari']

	url = 'https://www.affirm.com/mordor/debugapp/merchants/marqeta/%s/onboarding_card' % (merchant_ari)
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	res = requests.request(url=url, method=method, headers=headers)

	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	if res.status_code != 200:
		print(res.text)
		input('ERROR')
	checkOnboardingCard(res.text)
	return True