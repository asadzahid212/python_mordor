from getOmni import getOmni
from createOmni import createOmni

def mainGetOnboardingCard(onboardingCards):
	onboardingCards = onboardingCards #getOmni('omniCSV.csv')
	for i in onboardingCards:
		print(onboardingCards[i])
		# input('does this omni/landing_page look right?')
		createonboardingCard(onboardingCards[i])