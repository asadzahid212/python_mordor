from getSMS import getSMS
from deleteSMS import deleteSMS
from checkSMS import checkSMS

def mainDeleteSMS():

	SMS = getSMS('csvs/delete-sms.csv')
	print(SMS)
	for i in SMS:
		merchant_ari = SMS[i]['merchant_ari']
		deleteSMS(merchant_ari, SMS[i])

mainDeleteSMS()