#in: JSON of format:
"""
{
	name: "",
	priority: 1,
	financing_program_external_name: "",
	start_date: "",
	end_date: '',
	experiment_name: ''
}
"""
from checkOmni import checkOmni
import os
import requests

def createOmni(omni):
	merchant_ari = omni['merchant_ari']
	is_estimated_tax_rate_active = omni['is_estimated_tax_rate_active']
	estimated_tax_rate = omni['estimated_tax_rate']
	is_instore_page_active = omni['is_instore_page_active']
	instore_landing_page_url = omni['instore_landing_page_url'].replace('-','').replace('/','')
	while len(instore_landing_page_url) > 32:
		instore_landing_page_url = instore_landing_page_url[:-1]
	sandbox_enabled = omni['sandbox_enabled']
	instore_presentation_config = omni['instore_presentation_config']
	sms_instore_enabled = omni['sms_instore_enabled']
	sms_instore_link_template = omni['sms_instore_link_template']

	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/omnichannel_conf/' % (merchant_ari)
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {
		'estimated_tax_rate':estimated_tax_rate,
		'is_estimated_tax_rate_active':is_estimated_tax_rate_active,
		'is_instore_page_active':is_instore_page_active,
		'instore_landing_page_url':instore_landing_page_url,
		'sandbox_enabled':sandbox_enabled,
		'instore_presentation_config':instore_presentation_config,
		'sms_instore_enabled':sms_instore_enabled,
		'sms_instore_link_template':sms_instore_link_template
	}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	print(data)
	if res.status_code != 200:
		print('ERROR')
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	checkOmni(merchant_ari, instore_landing_page_url)
	return True