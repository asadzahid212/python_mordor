from getOmni import getOmni
from createOmni import createOmni

def mainLandingPage():
	omnis = getOmni('csvs/landing-page.csv')
	for i in omnis:
		print(omnis[i])
		# input('does this omni/landing_page look right?')
		createOmni(omnis[i])

mainLandingPage()