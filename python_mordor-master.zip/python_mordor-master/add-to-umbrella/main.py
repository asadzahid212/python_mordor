from addMerchantToUmbrella import addMerchantToUmbrella
# from checkUmbrella import checkUmbrella
from getARIs import getARIs

def mainUmbrella(umbrellas,oneoff=False):
	if oneoff:
		umbrellas = getARIs('csvs/add-to-umbrella.csv')
		
	else:
		umbrellas = umbrellas 
		print(umbrellas)
	for i in umbrellas:
		child_ari = umbrellas[i]['child_ari']
		parent_ari = umbrellas[i]['parent_ari']
		addMerchantToUmbrella(parent_ari, child_ari)
		# checkUmbrella(parent_ari, child_ari)
		# checkUmbrella(parent_ari, child_ari)
	
mainUmbrella(umbrellas=[],oneoff=True)