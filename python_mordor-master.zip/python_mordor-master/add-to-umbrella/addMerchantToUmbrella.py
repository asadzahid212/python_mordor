#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json

def addMerchantToUmbrella (parent_ari, child_ari):
	if not parent_ari or not child_ari:
		return True
	parent_ari = parent_ari
	child_ari = child_ari
	
	url = 'https://www.affirm.com/mordor/debugapp/merchants/umbrella/%s/child' % (parent_ari)
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id
	      }
	data = {
		'child_ari':child_ari
	}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	print(data)
	
	file_object = open("myupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	if res.status_code != 200:
		print('ERROR')
		input('wh')
	return True