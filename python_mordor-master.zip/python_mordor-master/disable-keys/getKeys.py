#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from bs4 import BeautifulSoup

def getKeys (merchant_ari):
	
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/' % (merchant_ari)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	print(data)
	if res.status_code != 200:
		print('ERROR')
	file_object = open("mykeyupdatefile.html", "w+")
	file_object.write(res.text)
	file_object.close()
	print(url)
	soup = BeautifulSoup(res.text, 'html.parser')
	public_keys = soup.find_all(class_="api-key-public")
	print(public_keys)
	live_key = False
	sandbox_key = False
	for public_key in public_keys:
		current_key_value = public_key.input['value']
		print(current_key_value)
		while "sandbox/api_keys" not in str(public_key) and "live/api_keys" not in str(public_key):
			# print('\n\n\n\nchecking next element')
			# print(public_key)
			# print("sandbox/api_keys" in public_key)
			# print("live/api_keys" in public_key)
			# print("sandbox/api_keys" not in str(public_key) and "live/api_keys" not in str(public_key))
			if "sandbox/api_keys" in str(public_key.previous_element):
				sandbox_key = current_key_value
			if "live/api_keys" in str(public_key.previous_element):
				live_key = current_key_value
			public_key = public_key.previous_element

	# ['value']
	# sandbox_key = soup.find(id='sandbox_public_key')['value']
	print('live key: ' + str(live_key))
	print('sandbox key: ' + str(sandbox_key))
	return {'live_key':live_key, 'sandbox_key':sandbox_key}

# getKeys('Z3YPL285ONVXFVAM')