from getMerchants import getMerchants
from generateKeys import generateKeys
from getKeys import getKeys
from disableKeys import disableKeys
from checkKey import checkKey

import sys
sys.path.insert(1, './shared')
from writeResultsToFirstColumnOfCSV import writeResultsToFirstColumnOfCSV

def mainDisableKeys():
	merchants = getMerchants('csvs/disable-keys.csv')
	
	keys = {}
	for i in merchants:
		merchant_ari = merchants[i]['merchant_ari']
		keys = getKeys(merchant_ari)
		public_api_key = {'merchant_ari':merchant_ari}
		print(merchants)
		print('does this key look right?')
		# merchant_ari = merchants[i]['merchant_ari']
		first_check = checkKey(merchant_ari, keys)
		if first_check == {"sandbox":{"exist": True,"active": False},"live":{"exist": True,"active": False}}:
			print('done with ' + merchant_ari)
			print(keys)
			public_api_key['key'] = keys['live_key']
			continue
		for mode in ['sandbox', 'live']:
			if first_check[mode] == {"exist": True,"active": False}:
				continue
			else:
				if first_check[mode]['exist'] == False:
					generateKeys(merchant_ari, mode)
				keys = getKeys(merchant_ari)
				if first_check[mode]['active'] == False:
					continue
				else:
					disableKeys(merchant_ari, keys[mode+'_key'])
			print('done with ' + mode + ' for ' + merchant_ari)
		last_check = checkKey(merchant_ari, keys)
		if last_check == {"sandbox":{"exist": True,"active": False},"live":{"exist": True,"active": False}}:
			print('done with ' + merchant_ari)
			print(keys)
			public_api_key['key'] =  keys['live_key']
		else:
			print(last_check)
			input('TAKE NOTE, '+ merchant_ari + 'DID NOT SUCCEED')
	writeResultsToFirstColumnOfCSV('csvs/disable-keys.csv', public_api_key['key'], public_api_key['merchant_ari'], 'merchant_ari', target_col_header='public_api_key')

mainDisableKeys()