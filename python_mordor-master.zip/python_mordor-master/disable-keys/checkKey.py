import requests
import os
import json
from bs4 import BeautifulSoup

def checkKey(merchant_ari, keys):
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/' % (merchant_ari)
	method = 'GET'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	
	result = {'sandbox':{'exist':False,'active':False},'live':{'exist':False,'active':False}}
	soup = BeautifulSoup(res.text, 'html.parser')
	for mode_key in keys:
		public_keys = soup.find_all(class_="api-key-public")
		for public_key in public_keys:
			#if the public key we're looking at is here
			try: 
				print(keys[mode_key] in str(public_key))
				button_text = public_key.parent.button.decode_contents().lower()
				button_mapping = {"deactivate":True, "activate":False}
				key_status = button_mapping[button_text]
				result[mode_key.replace('_key','')]['exist'] = True
				result[mode_key.replace('_key','')]['active'] = key_status
			except:
				pass




	# for mode in ['sandbox', 'live']:
	# 	exist = soup.find(id=mode+"_public_key")
	# 	active = soup.find(id=mode+"_active")

	# 	exist_validation = False
	# 	try:
	# 		if exist['value'] == '':
	# 			exist_validation = False
	# 			print('Merchant ARI ' + merchant_ari + ' does NOT have keys')
	# 		else:
	# 			exist_validation = True
	# 			print('Merchant ARI ' + merchant_ari + ' has keys')
	# 	except:
	# 		exist_validation = False
	# 		print('Merchant ARI ' + merchant_ari + ' does NOT have keys')

	# 	active_validation = False
	# 	try:
	# 		active['checked']
	# 		active_validation = True
	# 	except:
	# 		pass


	# 	if active_validation == True:
	# 		print('Merchant ARI ' + merchant_ari + ' ' + mode.upper() + ' is active ')
	# 	else:
	# 		print('Merchant ARI ' + merchant_ari + ' ' + mode.upper() + ' is NOT active')
	# 	validation = {
	# 	"exist": exist_validation,
	# 	"active": active_validation
	# 	}
	# 	result[mode] = validation
	# input(result)
	return result