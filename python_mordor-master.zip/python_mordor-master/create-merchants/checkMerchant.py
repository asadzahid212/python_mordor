#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json
from bs4 import BeautifulSoup

def checkMerchant (merchant_ari):
	
	if len(merchant_ari) < 16:
		return False
	else:
		return True
