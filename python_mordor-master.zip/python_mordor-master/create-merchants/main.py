from getMerchant import getMerchant
from createMerchant import createMerchant
from writeMerchant import writeMerchant

merchants = getMerchant('csvs/create-merchants.csv')
merchant_aris = ['merchant_ari']
for i in merchants:
	merchant_ari = createMerchant(merchants[i])
	merchant_aris.append(merchant_ari)
writeMerchant('csvs/create-merchants.csv', merchant_aris)