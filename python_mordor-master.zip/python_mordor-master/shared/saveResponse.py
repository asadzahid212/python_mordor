def saveResponse(res, file_name="default_"):
	file_object = open(file_name+"newupdatefile.html", "w+")
	file_object.write(res)
	file_object.close()
	# print(res)
	return True