import csv
def writeResultsToFirstColumnOfCSV(file_name, value, match_value, match_column,target_col_header):
	new_file = file_name[len(file_name)-4:] + '_finished.csv'
	with open(file_name, newline='') as csvfile:
		csvreader = csv.reader(csvfile, delimiter=',')
		with open(new_file, 'w') as writefile:
			csvwriter = csv.writer(writefile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
			columns = []
			row_num = 0
			match_col_num = 0
			target_col_num = 0
			for row in csvreader:
				#document columns for first row of csv
				if row_num == 0:
					columns = row 
					#check columns for the column we're looking for (merchant_ari)
					if match_column in columns:
						match_col_num = columns.index(match_column)
					else:
						return False
					if target_col_header in columns:
						target_col_num = columns.index(target_col_header)
						# input(target_col_num)
					else:
						row.insert(0,target_col_header)
						target_col_num = 0
				else:
					print(row)
					print(match_col_num)
					print(match_value)
					# input()
					if row[match_col_num] == match_value:
						print(row)
						print(value)
						print(row_num)
						# input('rows')
						row[target_col_num] = value
						print(row)
				csvwriter.writerow(row)


				row_num += 1
	copyCSVToOriginal(new_file, file_name)
	return True


def copyCSVToOriginal(file_to_copy, file_to_overwrite):
	with open(file_to_copy, newline='') as csvfile:
		csvreader = csv.reader(csvfile, delimiter=',')
		with open(file_to_overwrite, 'w') as writefile:
			csvwriter = csv.writer(writefile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)

			for row in csvreader:
				csvwriter.writerow(row)


