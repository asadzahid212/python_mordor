from createSMS import createSMS
from checkSMS import checkSMS

def processSMS(SMS):
	merchant_ari = SMS['merchant_ari']
	print('creating SMS: ' + str(SMS))
	createSMS(merchant_ari, SMS)
	validation = checkSMS(merchant_ari, SMS)
	if validation == True:
		print('SMS looks good!')
		pass
	else:
		input('SMS code looks bad for ' + str(SMS))
	return SMS