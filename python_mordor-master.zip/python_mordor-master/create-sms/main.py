import csv
from getSMS import getSMS
from processSMS import processSMS

def mainSMS():
	SMSes = getSMS('csvs/create-sms.csv')
	for i in SMSes:
		SMS = SMSes[i]
		processSMS(SMS)


mainSMS()