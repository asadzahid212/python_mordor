def getColumns(csv):
	columns = []
	for row in csv:
		for column in row:
			columns.append(column)
		break
	return columns