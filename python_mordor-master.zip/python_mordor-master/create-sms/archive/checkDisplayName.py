from getSMS import getSMS 

def checkDisplayName(SMS):
	display_name = SMS['display_name']
	instore_landing_page_url = SMS['instore_landing_page_url']
	dealer_name = SMS['dealer_name']
	if display_name != '':
		print('url: ' + instore_landing_page_url)
		print('display_name: ' + display_name)
		want = 'y' #input('is this what we want')
		if want == 'y':
			return display_name
	try:
		OEMCodes = getSMS('../5create-sms/OEMCodes.csv')
	except:
		OEMCodes = getSMS('OEMCodes.csv')

	possible_codes = []
	for i in OEMCodes:
		OEMCode = OEMCodes[i]
		OEM = OEMCode['OEM'].lower().replace(' ', '')
		code = OEMCode['code']
		print(OEM)
		print(OEMCode)
		print(dealer_name)
		# input(OEM.lower() in dealer_name.lower())

		if OEM in instore_landing_page_url.lower().replace(' ', '') or OEM.lower() in dealer_name.lower().replace(' ', ''):
			possible_codes.append(code)

	end_display_name = ''
	
	print(possible_codes)
	if len(possible_codes) > 1:
		print(possible_codes)
		possible_code = print('^^^There are multiple dealers in the name^^^\nWhich display name should we go with?')
		possible_code = ''
		for code in possible_codes:
			possible_code = possible_code + '_' + code
	elif len(possible_codes) == 0:
		print(SMS)
		possible_code = input("The script couldn't match an OEM/manufacturer based on the name of the dealer.\nIs this dealer associated with a particular OEM based on its name above? If so, please enter here: ")
	else:
		possible_code = possible_codes[0]
	
	end_display_name = possible_code + '_'
	end_display_name = SMS['display_name_prefix'] + '_' + end_display_name
	print(end_display_name)
	# input('Just confirming, is this the display name we want?')
	return end_display_name

