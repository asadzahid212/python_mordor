import csv
from getColumns import getColumns

def updateCSV(new_version_csv, csv_name, method='default'):
	old_file = []
	with open(csv_name, 'r') as readfile:
		csvreader = csv.reader(readfile, delimiter=',',
	                        quotechar='|', quoting=csv.QUOTE_MINIMAL)
		for row in csvreader:
			old_file.append(row)
	with open(csv_name, 'w') as writefile:
		csvwriter = csv.writer(writefile, delimiter=',',
	                        quotechar='|', quoting=csv.QUOTE_MINIMAL)
		if method == 'default':
			for row in new_version_csv:
				csvwriter.writerow(row)
		elif method == 'sms':
			old_columns = []
			print(new_version_csv)
			row_num = 0
			#take each row in old csv
			for old_row in old_file:
				#get the columns
				old_columns = getColumns(old_file)

				print(old_row)
				print('new_version_csv: ' + str(new_version_csv))
				#if it's the right one, overwrite it, otherwise keep old one. hope the first column is the id
				if new_version_csv['merchant_ari'] == old_row[old_columns.index('merchant_ari')]:
					old_row[old_columns.index('sms_keyword')] = new_version_csv['sms_keyword']
				csvwriter.writerow(old_row)
				row_num += 1
