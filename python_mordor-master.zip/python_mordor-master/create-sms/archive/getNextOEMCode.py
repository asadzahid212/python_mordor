#in: file name
#out: JSON of structure:
"""
{
	0: {
		'ari':''
	}
}
"""
import csv
from getColumns import getColumns
from updateCSVObject import updateCSVObject
from incrementSMSCode import incrementSMSCode

def getNextOEMCode(display_name, last_res=None):
	res = []
	if not last_res:
		csv_name = 'textCodeTracker.csv'
		try:
			with open(csv_name):
				pass
		except:
			csv_name = '../5create-sms/' + csv_name
		new_version_csv = []
		with open(csv_name, newline='') as csvfile:
			csvreader = csv.reader(csvfile, delimiter=',')
		
			columns = []
			row_num = 0
			print("ROW_NUM")
			print(row_num)
			for row in csvreader:
				print('ROOOOW')
				print(row)
				if row_num == 0:
					for column in row:
						columns.append(column)
				else:	
					column_num = 0
					#create key-value pairings of column header to value
					row_dict = {}
					for value in row:
						print('column num: ' + str(column_num))
						print(columns)
						print(columns[column_num])
						print(value)
						row_dict[columns[column_num]] = value
						column_num +=1

					#if the shortcode is in the display name per naming standards
					print("row_dict['code']")
					print(row_dict)
					print(row_dict['code'])
					if "_"+row_dict['code']+"_" in display_name:
						#if no value, just make it 1
						if row_dict['next_number'] == '':
							row_dict['next_number'] = 1
						#add this to list of possible SMS codes (ideally just one)
						res.append(row_dict['OEM'].replace(' ','')+row_dict['next_number'])
						#increase next_number value for next time
						row_dict['next_number'] = int(row_dict['next_number']) + 1
					for col in row_dict:
						#update new number, and I guess make sure the OEM and code are the same?
						row[columns.index(col)] = row_dict[col]			
				row_num += 1
				new_version_csv.append(row)
				print('NEW VERSION CSV: ' + str(new_version_csv))
		print('res is: ' + str(res))
		if len(res) > 1:
			# which = print('which one should we use?')
			#defaulting to first one, too much work to monitor
			which = res[0]
		elif len(res) == 0:
			print(row_dict)
			print(display_name)
			which = input("The script tried to figure out on its own what to use for the text code, but failed. Based on the above dict, what should the text code be? \n Usually we'd do dealer + number, or some unique string reflecting the name succinctly. Please input: ")
			#gotta actually add logic to use the which thing

		else:
			which = res[0]
		res = which
	else:
		#increase the code by one
		increment_object = incrementSMSCode(last_res['code'])
		last_res['code'] = increment_object['new_code']
		res = last_res

		#then update the new_version_csv so we write the right thing
		new_code = res['code']
		new_version_csv = updateCSVObject(last_res['new_version_csv'], new_code, oem=increment_object['oem'], num=increment_object['num'])



		return res
	return	{"code": res, "new_version_csv": new_version_csv, "csv_name": csv_name}