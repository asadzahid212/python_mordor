from checkSMS import checkSMS

from getSMS import getSMS
from createSMS import createSMS
from bs4 import BeautifulSoup

SMS = getSMS('SMSCSV.csv')
print(SMS)
for i in SMS:
	merchant_ari = SMS[i]['merchant_ari']
	html_doc = checkSMS(merchant_ari)
	soup = BeautifulSoup(html_doc, 'html.parser')
	sms_codes = soup.find_all(class_="sms_keyword")
	for code in sms_codes:
		sms_code = code.decode_contents(formatter='html')
		print('code: ' + sms_code)
		if sms_code == '101P':
			print('FOUND IT: ' + merchant_ari)
			input('is this it?')
