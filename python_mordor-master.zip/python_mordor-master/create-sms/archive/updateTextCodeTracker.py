import csv

def updateCSV(new_version_csv, csv_name):
	with open(csv_name, 'w') as writefile:
		csvwriter = csv.writer(writefile, delimiter=',',
	                        quotechar='|', quoting=csv.QUOTE_MINIMAL)
		for row in new_version_csv:
			csvwriter.writerow(row)