from mainSMS import mainSMS

mainSMS(oneoff=True)