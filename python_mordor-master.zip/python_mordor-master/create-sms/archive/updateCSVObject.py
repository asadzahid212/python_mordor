from getColumns import getColumns

def updateCSVObject(new_version_csv, new_code, oem, num):
	columns = getColumns(new_version_csv)
	for row in new_version_csv:
		csv_OEM = row[columns.index('OEM')]
		next_number = row[columns.index('next_number')]

		#if it's the right OEM that we're doing the code for, update the next_number to the new num
		if csv_OEM == oem:
			row[columns.index('next_number')] = num
			break

	return new_version_csv


