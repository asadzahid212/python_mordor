def incrementSMSCode(code):
	i = -1
	
	for char in code:
		try:
			int(char)
			i += 1
			break
		except:
			i += 1
			continue
	oem = code[:i]
	num = int(code[i:])
	num += 1

	new_code = oem + str(num)
	return {'new_code': new_code, 'oem': oem, 'num':num}