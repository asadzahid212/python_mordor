#in: merchant_ari, config JSON, page_type
#out: confirmation that it's done?
import requests
import os
import json

import sys
sys.path.insert(1, './shared')

from saveResponse import saveResponse

def createSMS (merchant_ari, SMS):
	sms_keyword = SMS['sms_keyword']
	display_name = SMS['display_name'].replace(' - ','_')[:32]
	# input('sms keyword: ' + sms_keyword)
	url = 'https://www.affirm.com/mordor/debugapp/merchants/%s/sms_keywords/new_store_and_keyword' % (merchant_ari)
	method = 'POST'
	session_id = os.environ.get('SESSION_ID') #'.eJyrVkpMyc3MU7KqVsrJT8_Miy9OLS7OzM-LTyzKVLJSMvc2MDD1tfCL8Aw08TBxdVeq1VFKzkjMyUnNS08FagJx8_NKUitKcGnQUSotTi3CZb6Te6RThEtgqJ-xpbOPoZenUm0tALikLwE.EY4KuA.OzkwwqfE3Fs9Yx324P3QJ4D3x2o' #os.environ.get('SESSION_ID')
	headers = {
	        'Content-Type': 'application/x-www-form-urlencoded',
	        'Cookie': 'admin_session=' + session_id,
	      }
	data = {
		'sms_keyword':sms_keyword,
		'display_name':display_name
	}
	res = requests.request(url=url, method=method, headers=headers, data=data)
	print(data)
	if res.status_code != 200:
		print('ERROR')
	saveResponse(res.text, "createSMS")
	# input(url)
	return True